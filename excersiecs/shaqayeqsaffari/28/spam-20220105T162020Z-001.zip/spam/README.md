# machine-learning-class
machine learning class - 001

## Information
* ##### Teacher: Dr. Farzin Yaghmaee - [Contact](mailto:f_yaghmaee@semnan.ac.ir)
* ##### TA : Amir Shokri - [Contact](mailto:amirshokri@semnan.ac.ir)

### Student Info :
* Full name : bahare mohammadpour
* github id : b-mohammadpour
* Email : mohammadpour.b1601@semnan.ac.ir
